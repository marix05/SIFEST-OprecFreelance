<?php $__env->startSection('index'); ?>

<section class="login" id="login">
    <div class="wrapper">
        <?php if(session()->has("success")): ?>
            <div class="alert success">
                <p class="alert_msg"><?php echo e(session("success")); ?></p>
                <i class="fa-solid fa-xmark alert_toggle"></i>
            </div>
        <?php endif; ?>
        <?php if(session()->has("error")): ?>
            <div class="alert error">
                <p class="alert_msg"><?php echo e(session("error")); ?></p>
                <i class="fa-solid fa-xmark alert_toggle"></i>
            </div>
        <?php endif; ?>
        
        <div class="container p_relative py20">
            <div class="title_font text_center mb12">
                <p class="text_big">Login</p>
                <p>Open Recruitment <span class="fc_red">Freelance SI Fest 2022</span></p>
            </div>
            <div class="form_wrapper box_lt_rb_side p6">
                <i class="box_lt_rb_side_design"></i>
                <form action="<?php echo e(route("login")); ?>" method="post" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <div class="form_container pb2">
                        <div class="form_group">
                            <div class="input_wrapper">
                                <div class="input_container">
                                    <div class="icon">
                                        <i class="fa-solid fa-id-card"></i>
                                    </div> 
                                    <div class="input_div">
                                        <p class="input_title title_font">Student ID (NIM)</p>
                                        <input type="text" name="NIM" id="NIM" minlength="14" maxlength="14" class="input" required>
                                    </div>
                                </div>
                                <?php $__errorArgs = ['NIM'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error_msg">
                                        <p class="text_xsm fc_red">
                                            <?php echo e($message); ?>

                                        </p>
                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="input_wrapper">
                                <div class="input_container">
                                    <div class="icon">
                                        <i class="fa-solid fa-lock"></i>
                                    </div> 
                                    <div class="input_div">
                                        <p class="input_title title_font">Password</p>
                                        <input type="password" name="password" id="password" class="input" required maxlength="20">
                                        <i class="password_visibility fa-solid fa-eye"></i>
                                    </div>
                                </div>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error_msg">
                                        <p class="text_xsm fc_red">
                                            <?php echo e($message); ?>

                                        </p>
                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="btn_container pb4">
                        <button type="submit" class="btn_right form_btn" name="submit">
                            <i class="btn_right_design"></i>
                            Login
                        </button>
                    </div>
                    <p class="text_sm text_center">
                        Haven't registered yet? 
                        <a href="<?php echo e(route("home")); ?>" class="fw_bold fc_red">
                            Register
                        </a>
                    </p>
                </form>
            </div>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts/web.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\Oprec-Freelance\resources\views/web/home/login.blade.php ENDPATH**/ ?>